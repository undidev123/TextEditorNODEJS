import { useState, useEffect, useRef } from 'react';
import './App.css';
import Toolbar from './components/toolbar';

function App() {
  const [mode, setMode] = useState(true);
  const outputRef = useRef(null);
  const [espelho, setEspelho] = useState('');
  const [editEnabled, setEditEnabled] = useState(true);

  useEffect(() => {
    const search = window.location.search;
    if (search === '?mode=edit') {
      setMode(true);
    } else if (search === '?mode=view') {
      setMode(false);
    } else {
      window.location.href = window.location.pathname + '?mode=edit';
    }
  }, []);

  useEffect(() => {
    const textoSalvo = localStorage.getItem('texto');
    const html = textoSalvo || conteudoPadrao;

    if (outputRef.current) {
      outputRef.current.innerHTML = html;
      setEspelho(html);
    }

    if (!textoSalvo) {
      localStorage.setItem('texto', conteudoPadrao); // salva o padrão no primeiro uso
    }
  }, []);

  const handleInput = () => {
    if (outputRef.current) {
      const html = outputRef.current.innerHTML;
      setEspelho(html);
      localStorage.setItem('texto', html);
    }
  };



  return (
    <>
      <Toolbar outputRef={outputRef} />
      <div
        id="output"
        contentEditable={mode}
        ref={outputRef}
        onInput={editEnabled ? handleInput : null}
        style={{ border: '1px solid #ccc', padding: '10px', minHeight: '100px' }}
      />
    </>
  );
}

export default App;
