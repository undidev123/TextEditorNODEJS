import React from 'react';

const Toolbar = () => {
  const Execute = (command) => {
    if (command === "createlink") {
      let url = prompt("Qual é o link:");
      if (url) {
        document.execCommand(command, false, url);
      } else {
        document.execCommand(command, false, null);
      }
    } else {
      document.execCommand(command, false, null);
    }
  };

  const toggleTitle = () => {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
  
    const range = selection.getRangeAt(0);
    let parent = range.commonAncestorContainer;
  
    if (parent.nodeType === 3) {
      parent = parent.parentNode;
    }

    if (parent.nodeName === 'H1') {
        document.execCommand('formatBlock', false, 'p');
      } else {
        document.execCommand('formatBlock', false, 'h1');
      }
  }

  return (
    <div className='toolsbar'>
      <button onClick={() => Execute('bold')}><b>B</b></button>
      <button onClick={() => Execute('italic')}><i>I</i></button>
      <button onClick={() => Execute('underline')}><u>U</u></button>
      <button onClick={() => Execute('justifyLeft')}>Esquerda</button>
      <button onClick={() => Execute('justifyCenter')}>Centro</button>
      <button onClick={() => Execute('justifyRight')}>Direita</button>
      <button onClick={() => Execute('insertOrderedList')}>Ordem</button> 
      <button onClick={toggleTitle}>Criar/Remover Título</button>
      <button onClick={() => Execute('createlink')}>Criar Hyperlink</button>
    </div>
  );
};

export default Toolbar;
